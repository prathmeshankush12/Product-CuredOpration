create database Products
create table products(
ProductId int primary key identity,
ProductName varchar(100),
CategoryId int,
CategoryName varchar(200),
)
select * from products;